//
//  PlayView.swift
//  JustTakeThat
//
//  Created by Leonard Theodorus on 15/04/23.
//

import SwiftUI
struct PlayView: View {
    @State var playGame = false
    var body: some View {
        NavigationView {
            ZStack{
                Image("background2").resizable().aspectRatio(contentMode: .fill).edgesIgnoringSafeArea(.all)
                VStack{
                    Spacer()
                    Text("Guiding Lights").foregroundColor(.white)
                        .font(.custom("Allura-Regular", size: 128))
                    Spacer()
                    NavigationLink(destination: Instructions(playGame: $playGame).navigationBarBackButtonHidden(true)) {
                        Image(systemName: "play.fill")
                            .resizable()
                            .frame(width: 70, height: 70)
                            .padding(40)
                            .padding(.leading, 15)
                            .foregroundColor(.black)
                            .foregroundStyle(LinearGradient(colors: [.blue, .indigo], startPoint: .top, endPoint: .bottom))
                            .background(.ultraThinMaterial, in : Circle())
                            .padding(.bottom, 50)
                      
                    }.navigationBarBackButtonHidden(true)
                }
                .padding(.bottom, 350)
                Spacer()

            }.onDisappear{
                Sounds.playAudio()
            }
        }.onAppear{
            Sounds.audioStop()
        }
        .background(Image("background.jpg")).navigationViewStyle(.stack).onAppear{
            var fontURL = Bundle.main.url(forResource: "ChanticleerRomanNF", withExtension: ".ttf")
            CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
            fontURL = Bundle.main.url(forResource: "Allura-Regular", withExtension: ".ttf")
            CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        }
    }
}

struct PlayView_Previews: PreviewProvider {
    static var previews: some View {
        PlayView()
    }
}
