//
//  GameViewController.swift
//  JustTakeThat
//
//  Created by Leonard Theodorus on 07/04/23.
//
import UIKit
import SceneKit
import Combine
import SwiftUI
let winEvent = PassthroughSubject<Void, Never>()
class GameViewController: UIViewController {
    var gameEnded = false
    var sceneView : SCNView! = SCNView()
    var scene : SCNScene!
    var camNode : SCNNode!
    var portal : SCNNode!
    var sounds : [String : SCNAudioSource] = [:]
    let messageView = UIView()
    @State var controller = vcVM()
    func loadScene(){
        sceneView.frame = CGRect(origin: .zero, size: view.frame.size)
        scene = SCNScene(named: "GameScene.scn")
        sceneView.delegate = self
        sceneView.allowsCameraControl = false
        scene.physicsWorld.contactDelegate = self
        sceneView.scene = scene
        view.addSubview(sceneView)
    }
    func setupNodes(){
        camNode = scene.rootNode.childNode(withName: "cam", recursively: true)!
        portal = scene.rootNode.childNode(withName: "end", recursively: true)!
    }
    func setupSounds(){
        let finishSoundEffect = SCNAudioSource(fileNamed: "effect1.mp3")!
        finishSoundEffect.load()
        finishSoundEffect.volume = 0.7
        sounds["effect"] = finishSoundEffect
    }
    func createParticleSystem() -> SCNParticleSystem{
        let particleSys = SCNParticleSystem()
        particleSys.loops = true
        particleSys.birthRate = 100000
        particleSys.particleMass = 0.5
        particleSys.emissionDuration = 10
        particleSys.particleSize = 0.08
        particleSys.emitterShape = SCNTorus(ringRadius: 10, pipeRadius: 1)
        particleSys.particleLifeSpan = 10
        particleSys.particleVelocity = 1.2
        particleSys.particleColor = UIColor.systemOrange
        particleSys.isAffectedByPhysicsFields = true
        return particleSys
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadScene()
        setupNodes()
        setupSounds()
    }
}
extension GameViewController : SCNSceneRendererDelegate{
    func position(_ position: SCNVector3, multipliedByRotation rotation: SCNVector4) -> SCNVector3 {
        if rotation.w == 0 {
            return position
        }
        let rotMat = SCNMatrix4MakeRotation(rotation.w, rotation.x, rotation.y, rotation.z)
        let posMat = SCNMatrix4MakeTranslation(position.x, position.y, position.z)
        let transformMat = SCNMatrix4Mult(posMat, rotMat)
        
        return SCNVector3(transformMat.m41, transformMat.m42, transformMat.m43)
    }

    public func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        var newX = CGFloat(0.0)
        let newY = CGFloat(0.0)
        var newZ = CGFloat(0.0)
        var step : CGFloat = 0.05
        step /= 2
        let leftThumbstick = self.controller.controller.controller.controller?.extendedGamepad?.leftThumbstick
        leftThumbstick?.valueChangedHandler = { _ , x, y in
            if (x <= -0.25 && x >= -1){
                newX -= step
                if y <= -0.25 && y >= -1{
                    newZ += step
                }
                else if y >= 0.25 && y <= 1{
                    newZ -= step
                }
            }
            else if x >= 0.25 && x <= 1{
                newX += step
                if y <= -0.25 && y >= -1{
                    newZ += step
                }
                else if y >= 0.25 && y <= 1{
                    newZ -= step
                }
            }
            if y <= -0.25 && y >= -1{
                newZ += step
            }
            else if y >= 0.25 && y <= 1{
                newZ -= step
                
            }
            var camTransform = self.camNode.transform
            let rotatedPosition = self.position(SCNVector3Make(Float(newX), Float(newY), Float(newZ)), multipliedByRotation: self.camNode.rotation)
            camTransform = SCNMatrix4Translate(camTransform, rotatedPosition.x, rotatedPosition.y, rotatedPosition.z)
            self.camNode.transform = camTransform
        }
        var angle = 0.05
        angle /= 3
        let rightThumbstick = self.controller.controller.controller.controller?.extendedGamepad?.rightThumbstick
        var camTransform = self.camNode.transform
        camTransform = self.camNode.transform
        rightThumbstick?.valueChangedHandler = {_, x, y in
            if x <= -0.5 && x >= -1{
                camTransform = SCNMatrix4Rotate(camTransform, Float(angle), 0.0, 1.0, 0.0)
            }
            else if x >= 0.5 && x <= 1{
                camTransform = SCNMatrix4Rotate(camTransform, -Float(angle), 0.0, 1.0, 0.0)
            }
            self.camNode.transform = camTransform
        }
       
    }
    
    
}

extension GameViewController : SCNPhysicsContactDelegate{
    func physicsWorld(_ world: SCNPhysicsWorld, didBegin contact: SCNPhysicsContact) {
        let nodeA = contact.nodeA
        let nodeB = contact.nodeB
        if nodeA == camNode{
            let particleSys = createParticleSystem()
            nodeA.addParticleSystem(particleSys)
            nodeA.physicsBody = nil
            controller.controller.controller.disconnect()
            let finishEffect = sounds["effect"]!
            nodeA.runAction(SCNAction.playAudio(finishEffect, waitForCompletion: false))
            DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                winEvent.send()
            }

        }
        else if nodeB == camNode{
            let particleSys = createParticleSystem()
            nodeB.addParticleSystem(particleSys)
            nodeA.physicsBody = nil
            controller.controller.controller.disconnect()
            DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                winEvent.send()
            }
        }
        
        
    }
}
