//
//  EndScreen.swift
//  JustTakeThat
//
//  Created by Leonard Theodorus on 16/04/23.
//

import SwiftUI

struct EndScreen: View {
    @State var first = ""
    @State var second = ""
    @State var third = ""
    @State var fourth = ""
    let finalFirst = "In life, there will be times where you can't see your way through."
    let finalSecond = "Negative thoughts and doubts starts to come your way."
    let finalThird = "But, if you just can see your very next step no matter how little it is."
    let finalFourth = "Then just take that."
    var body: some View {
        NavigationView {
            ZStack{
                Color(.black).edgesIgnoringSafeArea(.all)
                VStack(alignment: .center, spacing: 15){
                    Text(first).onAppear{
                        typeWriterFirst()
                    }.foregroundColor(.white)
                    if first == finalFirst{
                        Text(second).onAppear{
                            typeWriterSecond()
                        }.foregroundColor(.white)
                    }
                    if second == finalSecond{
                        Text(third).onAppear{
                            typeWriterThird()
                        }.font(.custom("ChanticleerRomanNF", size: 28))
                        .foregroundColor(.white)
                            
                    }
                    if third == finalThird{
                        Text(fourth).onAppear{
                            typeWriterFourth()
                        }.foregroundColor(.white)
                    }
                    if fourth == finalFourth{
                        NavigationLink(destination: PlayView().navigationBarBackButtonHidden(true), label: {
                            Text("Thank you for playing. Tap here to return to main menu.")
                                .lineSpacing(70)
                        })
                        
                    }
                }
                .font(.custom("ChanticleerRomanNF", size: 30))
            }
            
        }
        .navigationViewStyle(.stack)
        
    }
    func typeWriterFirst(at position : Int = 0){
        if position == 0 {
            first = ""
        }
        if position < finalFirst.count {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) {
                first.append(finalFirst[position])
                typeWriterFirst(at: position + 1)
            }
        }
    }
    func typeWriterSecond(at position : Int = 0){
        if position == 0 {
            second = ""
        }
        if position < finalSecond.count {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) {
                second.append(finalSecond[position])
                typeWriterSecond(at: position + 1)
            }
        }
    }
    func typeWriterThird(at position : Int = 0){
        if position == 0 {
            third = ""
        }
        if position < finalThird.count {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) {
                third.append(finalThird[position])
                typeWriterThird(at: position + 1)
            }
        }
    }
    func typeWriterFourth(at position : Int = 0){
        if position == 0 {
            fourth = ""
        }
        if position < finalFourth.count {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) {
                fourth.append(finalFourth[position])
                typeWriterFourth(at: position + 1)
            }
        }
    }
}

struct EndScreen_Previews: PreviewProvider {
    static var previews: some View {
        EndScreen()
    }
}
