//
//  App.swift
//  JustTakeThat
//
//  Created by Leonard Theodorus on 08/04/23.
//

import SwiftUI
@main
struct justApp : App{
    var body: some Scene{
        WindowGroup{
            PlayView()
        }
    }
}
