//
//  VirtualControllerModel.swift
//  JustTakeThat
//
//  Created by Leonard Theodorus on 09/04/23.
//

import Foundation
import GameController
class virtualController : ObservableObject{
    var controller : GCVirtualController
    init(){
        let conf = GCVirtualController.Configuration()
        let controllerElements : Set = [GCInputLeftThumbstick, GCInputRightThumbstick]
        conf.elements = controllerElements
        let controller = GCVirtualController(configuration: conf)
        self.controller = controller
    }
    func disconnectController(){
        controller.disconnect()
    }
}

class vcVM : ObservableObject{
    var controller : virtualController = virtualController()
    init(){
        controller.controller.connect()
    }
}
