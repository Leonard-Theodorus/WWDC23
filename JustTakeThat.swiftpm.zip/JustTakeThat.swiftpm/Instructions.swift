//
//  Instructions.swift
//  JustTakeThat
//
//  Created by Leonard Theodorus on 16/04/23.
//

import SwiftUI

struct Instructions: View {
    @Binding var playGame : Bool
    @State var first : String = ""
    @State var second : String = ""
    @State var third : String = ""
    @State var fourth : String = ""
    @State var startGame : Bool = false
    let finalFirst = "I am trapped in this world of nothingness."
    let finalSecond = "I need to find a way to get back to my world."
    let finalThird = "I saw lights..."
    let finalFourth = "My best bet, is to just follow it..."
    var body: some View {
        NavigationView {
            ZStack{
                Color.black.edgesIgnoringSafeArea(.all)
                VStack(spacing: 15){
                    if playGame{
                        Text(first).onAppear{
                            typeWriterFirst()
                        }.foregroundColor(.white)
                        if first == finalFirst{
                            Text(second).onAppear{
                                typeWriterSecond()
                            }.foregroundColor(.white)
                        }
                        if second == finalSecond{
                            Text(third).onAppear{
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1){
                                    typeWriterThird()
                                }
                                
                            }.foregroundColor(.white)
                        }
                        if third == finalThird{
                            Text(fourth).onAppear{
                                typeWriterFourth()
                                
                            }.foregroundColor(.white)
                        }
                        if fourth == finalFourth{
                            NavigationLink(destination: ContentView(gameEnded: false).navigationBarBackButtonHidden(true), label: {
                                Text("Tap Here To Start The Journey")
                                    .lineSpacing(70)
                            })
                            
                        }
                    }
                }.font(.custom("ChanticleerRomanNF", size: 36))
                .lineSpacing(50)
                .onAppear{
                    playGame.toggle()
                }
                
            }
        }
        .navigationViewStyle(.stack)
        
        
    }
    func typeWriterFirst(at position : Int = 0){
        
        if position == 0 {
            first = ""
        }
        if position < finalFirst.count {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) {
                first.append(finalFirst[position])
                typeWriterFirst(at: position + 1)
            }
        }
    }
    func typeWriterSecond(at position : Int = 0){
        
        if position == 0 {
            second = ""
        }
        if position < finalSecond.count {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) {
                second.append(finalSecond[position])
                typeWriterSecond(at: position + 1)
            }
        }
    }
    func typeWriterThird(at position : Int = 0){
        
        if position == 0 {
            third = ""
        }
        if position < finalThird.count {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) {
                third.append(finalThird[position])
                typeWriterThird(at: position + 1)
            }
        }
    }
    func typeWriterFourth(at position : Int = 0){
        
        if position == 0 {
            fourth = ""
        }
        if position < finalFourth.count {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) {
                fourth.append(finalFourth[position])
                typeWriterFourth(at: position + 1)
            }
        }
    }
}

struct Instructions_Previews: PreviewProvider {
    static var previews: some View {
        Instructions(playGame: .constant(true))
    }
}
extension String {
    subscript(offset: Int) -> Character {
        self[index(startIndex, offsetBy: offset)]
    }
}
