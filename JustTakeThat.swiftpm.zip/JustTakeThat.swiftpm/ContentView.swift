//
//  ContentView.swift
//  JustTakeThat
//
//  Created by Leonard Theodorus on 08/04/23.
//

import SwiftUI
struct ContentView: View {
    @State var gameEnded : Bool = false
    var body: some View {
        ZStack{
            GameViewControllerRepresentable()
            if gameEnded{
                EndScreen()
                    .onDisappear{
                    gameEnded.toggle()
                }
            }
        }.ignoresSafeArea()
            .onReceive(winEvent){
                gameEnded.toggle()
            }
    }
}
struct GameViewControllerRepresentable : UIViewControllerRepresentable{
    func makeUIViewController(context: Context) -> GameViewController {
        return GameViewController()
    }
    func updateUIViewController(_ uiViewController: GameViewController, context: Context) {
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(gameEnded: false)
    }
}
