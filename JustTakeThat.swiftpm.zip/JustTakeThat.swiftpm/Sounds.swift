//
//  Sounds.swift
//  JustTakeThat
//
//  Created by Leonard Theodorus on 16/04/23.
//

import Foundation
import AVFoundation

public class Sounds{
    static var audioPlayer : AVAudioPlayer?
    public static func playAudio(){
        do{
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.ambient)
            try audioSession.setActive(true)
            guard let url = Bundle.main.url(forResource: "Petrichor", withExtension: ".wav") else {return}
            Sounds.audioPlayer = try? AVAudioPlayer(contentsOf: url)
            Sounds.audioPlayer?.numberOfLoops = 1
            Sounds.audioPlayer?.volume = 0.6
            Sounds.audioPlayer?.play()
        }
        catch{
            print(error.localizedDescription)
        }
        
    }
    public static func audioStop(){
        Sounds.audioPlayer?.stop()
    }
}
